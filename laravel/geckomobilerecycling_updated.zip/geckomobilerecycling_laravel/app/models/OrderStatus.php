<?php

class OrderStatus extends Eloquent {
    
    protected $table = 'orders_statuses';
    
}