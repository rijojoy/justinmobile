@extends('layouts.front.front')

@section('content')

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<link rel="stylesheet" href="/assets/css/print.css" type="text/css" media="print" />

<h1>Thank you</h1>

@if($status == 1)

<p>
  Your sale has been registered and a confirmation email has been sent to {{ $personal_info['email'] }}. <b>If you don't receive it shortly, please check your junk folder as it may have been flagged as spam</b>. If you have any questions about your sell order please <a href="https://www.geckomobilerecycling.co.uk/contact" target="_blank">contact us</a> quoting your Sale Number {{ $order_id }}.
<p><b>Show us some love. Like and Share :)</b> <div class="fb-like" data-href="https://www.facebook.com/GeckoMobileRecycling" data-width="1140" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div></p>
<h3>What happens next?</h3>
  We will send instructions, packaging and a postage label to your address 1st class, unless you chose to use your own postage and packaging.</p>
<p>
If you chose to use your own postage and packaging, please send your device to:</p>
<p>Gecko Mobile<br>
  Suite 143<br>
3 Edgar Buildings<br>
George Street<br>
  Bath<br>
BA1 2FJ</p>
<p><em>When using your own postage and packaging:</em></p>
<p>- Do remember to include your Sale Number {{ $order_id }} with your device as this allows us to link it to you.</p>
<p>- Do <a href="https://www.geckomobilerecycling.co.uk/erase" target="_blank">remove Apple's Activation Lock</a>.</p>
<p>- Royal Mail Special Delivery recommended, it is insured up to £500 and you can track the parcel.</p>

@elseif ($status == 0)

<p>Your sale has been registered and a confirmation email has been sent. Because your device is damaged or faulty we will e-mail you a customised quote for your device. Once you have accepted this quote we will send you details on what to do next.</p>

@endif
<br />
<form>
        <input type="button" name="print" value="Print this page" class="btn btn-gecko btn-md" onClick="window.print()">
    </form>
</p>
<h3 style="margin-top:20px;">One more thing before you go… What can we do better?</h3>
@if(Session::has('message'))
	<div class="alert alert-global alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		{{ Session::get('message') }}
		<?php $sent = true; ?>
	</div>
@endif
@if(Session::has('errors'))
	<div class="alert alert-global alert-danger">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php echo $errors->first(); ?>
	</div>
@endif
<div class="row">
{{ Form::open(array('url' => 'feedback/submit', 'class' => 'vertical')) }}
<div class="col-md-8">
	<div class="form-group">
		<textarea name="message" id="message" class="form-control" rows="6" placeholder="Your feedback..." required<?php if(isset($sent)) { ?> disabled<?php } ?>></textarea>
	</div>
	{{ Form::hidden('order_id', Input::get('order')) }}
</div>
<?php if(!isset($sent)) { ?>
<div class="col-md-8">
	<div class="form-group">
		{{ Form::button('Send Message', array('type' => 'submit', 'class' => 'btn btn-gecko btn-md')) }}
	</div>
</div>
<?php } ?>
{{ Form::close() }}
</div>

<!-- Google Code for Registered sale Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 974242067;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "9bL5CKWgmggQk4LH0AM";
var google_conversion_value = 0;
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src=" https://www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src=" https://www.googleadservices.com/pagead/conversion/974242067/?value=0&amp;label=9bL5CKWgmggQk4LH0AM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script src="//platform.twitter.com/oct.js" type="text/javascript"></script>
<script type="text/javascript">
twttr.conversion.trackPid('l48gi');
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://analytics.twitter.com/i/adsct?txn_id=l48gi&p_id=Twitter" />
</noscript>

<!-- Facebook Conversion Code for Register Sale -->
<script type="text/javascript">
var fb_param = {};
fb_param.pixel_id = '6013263164813';
fb_param.value = '0.01';
fb_param.currency = 'GBP';
(function(){
var fpw = document.createElement('script');
fpw.async = true;
fpw.src = '//connect.facebook.net/en_US/fp.js';
var ref = document.getElementsByTagName('script')[0];
ref.parentNode.insertBefore(fpw, ref);
})();
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6013263164813&amp;value=0.01&amp;currency=GBP" /></noscript>
</script>

<script type="text/javascript">
<!--
var ref="{{ $order_id }}"; //Your unique reference
var mid="33361";
var goalid="1838";
//-->
</script>
<script type="text/javascript" src="https://aflite.co.uk/js/track.js"></script>

<img src="https://www.clixGalore.com/AdvTransaction.aspx?AdID=15240&OID=<?php echo $order_id;?>" height="0" width="0" border="0">

<!-- Begin StoreYa script -->
<script type="text/javascript">
 //<![CDATA[
(function () {
 	function load_js() {
 		var s = document.createElement('script');
 		s.type = 'text/javascript';
 		s.async = true;
 		s.src = '//www.storeya.com/externalscript/ReferFriend';
 		var x = document.getElementsByTagName('script')[0];
 		x.parentNode.insertBefore(s, x)
 	}
 	if (window.attachEvent)
 		window.attachEvent('onload', load_js);
 	else
 		window.addEventListener('load', load_js, false)
})();

var _storeya = _storeya || [];
var _storeya_order_details = {
 	SiteID : '49172779',
 	OrderID : "{{ $order_id }}",
 	SubTotal : "{{ $personal_info['myprice'] }}",
 	Email : "{{ $personal_info['email'] }}",
 	CustomerName : "{{ $personal_info['name'] }}",
};

 _storeya.push([_storeya_order_details]);
 //]]>
</script><!-- End StoreYa script -->


@stop