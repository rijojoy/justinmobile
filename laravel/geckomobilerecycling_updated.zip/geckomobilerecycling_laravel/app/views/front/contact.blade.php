@extends('layouts.front.front')
@section('content')

<h4>We're here to help!</h4>
<p>Contact us any time using the details below. If you <span><a href="mailto:support@geckomobilerecycling.co.uk">email us</a></span> we'll usually get back to you within a few hours.</p>
@stop