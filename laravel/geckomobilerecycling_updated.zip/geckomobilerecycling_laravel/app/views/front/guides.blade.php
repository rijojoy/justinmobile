@extends('layouts.front.front')

@section('content')

<h1>How to erase your device</h1>
<p>
	Please protect your personal data and help us process your device faster by erasing and resetting your iPhone or iPad before sending it to us.
</p> <p>
Erase all content and settings by choosing Settings > General > Reset > Erase All Content and Settings. You will need to provide your Apple ID and password.
</p>
@stop