<head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-46885631-1', 'geckomobilerecycling.co.uk');
  ga('send', 'pageview');

</script>
</head>
<body>
<div class="col-md-6">
<h1>Contact Us</h1>
                    <p>
                        If you have any questions don't hesitate to get in touch!
                    </p>        
        <span class="c_icon"><img src="/assets/images/contact/icon_contact_sphone_11.png" title="Static Phone"></span>                     
		        <span>Call: 01392 690189</span>
		<br /><br />
        <span class="c_icon"><img src="/assets/images/contact/icon_contact_location_11.png" alt="Address" title="Address"></span>         
		        <span>Mail: Queensgate House, 48 Queen Street, Exeter, EX4 3SR</span>
                </div>
</body>