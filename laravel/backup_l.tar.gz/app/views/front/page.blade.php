@extends('layouts.front.front')

@section('content')
@include($plain_page)
@stop