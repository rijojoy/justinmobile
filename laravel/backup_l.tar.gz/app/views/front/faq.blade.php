@extends('layouts.front.front')

@section('content')
<h1>FAQ</h1>
<h2>I have a question</h2>
<p>
    I have an answer!
</p>
@stop