<?php

class ProductModelPropertyOption extends Eloquent {
    
    protected $table = 'products_models_properties_options';
    
}