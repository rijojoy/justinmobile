<head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-46885631-1', 'geckomobilerecycling.co.uk');
  ga('send', 'pageview');

</script>
</head>
<body>
<h1>Frequently Asked Questions</h1>

<br><h2>Q: Can I trust you?</h2>

<br><b>A:</b> We are transparent about who we are, our reputation and how we protect your personal information.</br>

<br><b>Who we are:</b> Gecko Mobile Recycling is the trading name of Gadget Recycling Ltd., a Limited company registered in England & Wales (Company No. 8765449).</br>

<br><b>Our reputation:</b> Online reviews are the best way of assessing the reputation an Internet company. Unfortunately, these are often fabricated and people often distrust online reviews as a result. To demonstrate our credibility, we have chosen to use <a href="http://www.trustpilot.co.uk/review/www.geckomobilerecycling.co.uk" target="_blank">TrustPilot</a> as our review platform. TrustPilot have a number of checks and balances in place to fight fake reviews, and reviews placed on their website are widely regarded as trustworthy because of this.</br>

<br><b>How we protect your personal information:</b> Your connection to our website is encrypted (you can tell because the web address starts with https rather than http) which means that if anyone intercepts the information you submit to us they will not be able to make sense of it as it will appear ‘jumbled’. We are careful with any personal information you submit and handle it in accordance with our <a href="https://www.geckomobilerecycling.co.uk/privacy" target="_blank">Privacy Policy</a>.

<br><h2>Q: Will you mark down the value of my mobile?</h2>

<br><b>A:</b> Other recylers have a reputation for luring in customers with inflated prices, just to mark down the value of their mobile once it arrives. Gecko Mobile Recycling has a grading system and a Price Promise to put your mind at ease. The grading system means we are transparent about how we assess the value of your mobile - we ask you to select the correct condition before you send it to us. And our Price Promise means that if we do have to mark down the value of your mobile because the incorrect condition was selected, we will return it to you for free if you wish. Other companies charge money for returns.</br>

<br><h2>Q: When will I be paid?</h2>

<br><b>A:</b> We will send payment the same day we receive your mobile. If you choose to use your own postage and packaging you could be paid as soon as tomorrow!</br>

<br><h2>Q: How long is the price quoted valid for?</h2>

<br><b>A:</b> The price quoted is valid for 14 days from the date you register your sale. If we receive your mobile after this, it will be valued at the website price on the day we receive it.</br>

</body>